local function initMod(modDirectory, modName)
	source(Utils.getFilename('scripts/RealDashboard.lua', modDirectory))
	
	TypeManager.finalizeTypes = Utils.prependedFunction(TypeManager.finalizeTypes, function (object)
		if object.typeName == "vehicle" then
			for typeName, typeEntry in pairs(object:getTypes()) do
				if SpecializationUtil.hasSpecialization(Drivable, typeEntry.specializations) and SpecializationUtil.hasSpecialization(Motorized, typeEntry.specializations) and SpecializationUtil.hasSpecialization(Dashboard, typeEntry.specializations) then
					object:addSpecialization(typeName, modName .. ".realDashboard")
				end
			end
		end
	end)
end

initMod(g_currentModDirectory, g_currentModName)