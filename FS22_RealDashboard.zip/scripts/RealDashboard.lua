--[[

Game:    Farming Simulator 22
Script:  RealDashboard
Author:  ThundR (FS19), Perma's Modding (FS22)
Created: 12/26/2020

--]]

-- <<[Declarations]>> -----------------------------------------------------------------------------

local g_modName = g_currentModName
local g_specName = "spec_"..g_modName..".realDashboard"

RealDashboard = {REALDASHBOARD_CONFIG_XML_KEY = "vehicle.realDashboard(?)"}
RealDashboard.DISPLAY_MODE = {
    NORMAL = 1,
    ROOT   = 2,
    TOTAL  = 3
}

function RealDashboard.initSpecialization()
	local schema = Vehicle.xmlSchema
	
	schema:setXMLSpecializationType("RealDashboard")
	schema:register(XMLValueType.STRING, RealDashboard.REALDASHBOARD_CONFIG_XML_KEY .. "#fillTypes", "Fill types")
	schema:register(XMLValueType.STRING, RealDashboard.REALDASHBOARD_CONFIG_XML_KEY .. "#fillTypeCategories", "Fill type categories")
	RealDashboard.registerDashboardXMLPaths(schema, "vehicle.realDashboard.dashboards")
	
	schema:setXMLSpecializationType()
end

function RealDashboard.registerDashboardXMLPaths(schema, basePath, availableValueTypes)
	schema:register(XMLValueType.STRING, basePath .. ".dashboard(?)#valueType", string.format("Value type name (Available: %s)", availableValueTypes or "no valueTypes available here"))
	schema:register(XMLValueType.STRING, basePath .. ".dashboard(?)#displayType", "Display type name")
	schema:register(XMLValueType.STRING, basePath .. ".dashboard(?)#groups", "List of groups")
	schema:register(XMLValueType.NODE_INDEX, basePath .. ".dashboard(?)#node", "(EMITTER | ROT | VISIBILITY) Node")
	schema:register(XMLValueType.BOOL, basePath .. ".dashboard(?)#doInterpolation", "Do interpolation", false)
	schema:register(XMLValueType.FLOAT, basePath .. ".dashboard(?)#interpolationSpeed", "Interpolation speed", 0.005)
	schema:register(XMLValueType.FLOAT, basePath .. ".dashboard(?)#idleValue", "Idle value", 0)
	schema:register(XMLValueType.NODE_INDEX, basePath .. ".dashboard(?)#numbers", "(NUMBER) Numbers node")
	schema:register(XMLValueType.STRING, basePath .. ".dashboard(?)#numberColor", "(NUMBER) Numbers color (DashboardColor OR BrandColor OR r g b a)")
	schema:register(XMLValueType.INT, basePath .. ".dashboard(?)#precision", "(NUMBER) Precision", 1)
	schema:register(XMLValueType.STRING, basePath .. ".dashboard(?)#font", "(NUMBER) Name of font to apply to mesh", "DIGIT")
	schema:register(XMLValueType.BOOL, basePath .. ".dashboard(?)#hasNormalMap", "(NUMBER) Normal map will be applied to number decals", false)
	schema:register(XMLValueType.FLOAT, basePath .. ".dashboard(?)#emissiveScale", "(NUMBER) Scale of emissive map", 0.2)
	schema:register(XMLValueType.STRING, basePath .. ".dashboard(?)#textColor", "(TEXT) Font color (DashboardColor OR BrandColor OR r g b a)")
	schema:register(XMLValueType.STRING, basePath .. ".dashboard(?)#hiddenColor", "(TEXT) Color of hidden character (if defined a '0' in this color is display instead of nothing)")
	schema:register(XMLValueType.STRING, basePath .. ".dashboard(?)#textAlignment", "(TEXT) Alignment of text (LEFT | RIGHT | CENTER)", "RIGHT")
	schema:register(XMLValueType.FLOAT, basePath .. ".dashboard(?)#textSize", "(TEXT) Size of font in meter", 0.03)
	schema:register(XMLValueType.FLOAT, basePath .. ".dashboard(?)#fontThickness", "(TEXT) Thickness factor for font characters", 1)
	schema:register(XMLValueType.FLOAT, basePath .. ".dashboard(?)#textScaleX", "(TEXT) Global X scale of text", 1)
	schema:register(XMLValueType.FLOAT, basePath .. ".dashboard(?)#textScaleY", "(TEXT) Global Y scale of text", 1)
	schema:register(XMLValueType.STRING, basePath .. ".dashboard(?)#textMask", "(TEXT) Font Mask", "00.0")
end

function RealDashboard.registerEventListeners(vehicleType)
    SpecializationUtil.registerEventListener(vehicleType, "onLoad",                 RealDashboard)
    SpecializationUtil.registerEventListener(vehicleType, "onUpdate",               RealDashboard)
    SpecializationUtil.registerEventListener(vehicleType, "onRegisterActionEvents", RealDashboard)
end

function RealDashboard.registerFunctions(vehicleType)
    SpecializationUtil.registerFunction(vehicleType, "rdbGetFillLevel",     RealDashboard.rdbGetFillLevel)
    SpecializationUtil.registerFunction(vehicleType, "rdbGetFillMass",      RealDashboard.rdbGetFillMass)
    SpecializationUtil.registerFunction(vehicleType, "rdbGetFillDensity",   RealDashboard.rdbGetFillDensity)
    SpecializationUtil.registerFunction(vehicleType, "rdbGetFillLevelInfo", RealDashboard.rdbGetFillLevelInfo)
    SpecializationUtil.registerFunction(vehicleType, "rdbGetDisplayMode",   RealDashboard.rdbGetDisplayMode)
    SpecializationUtil.registerFunction(vehicleType, "rdbGetVolumeUnit",    RealDashboard.rdbGetVolumeUnit)
    SpecializationUtil.registerFunction(vehicleType, "rdbGetMassUnit",      RealDashboard.rdbGetMassUnit)
    SpecializationUtil.registerFunction(vehicleType, "rdbGetDensityUnit",   RealDashboard.rdbGetDensityUnit)
end

function RealDashboard:getLastSpeedRD(useAttacherVehicleSpeed)
	-- if useAttacherVehicleSpeed and self.attacherVehicle ~= nil then
		-- return self.attacherVehicle:getLastSpeed(true)
	-- end

	-- if g_gameSettings:getValue(GameSettings.SETTING.USE_MILES) then
		-- return self.lastSpeed * 0.621371 * 3600
	-- end
	
	-- return self.lastSpeed * 3600
	return 3600
end

-- <<[[Event Functions]>> -------------------------------------------------------------------------

function RealDashboard:onLoad(savegame)
    local spec = self[g_specName]
    local baseKey = "vehicle.realDashboard"
    local dashboardKey = baseKey..".dashboards"

    local xmlFile = self.xmlFile
    local isActive = false


	-- Real Dashboard Speed

	-- Our replacement function
	function self:getLastSpeedRD(useAttacherVehicleSpeed)

		if g_gameSettings:getValue(GameSettings.SETTING.USE_MILES) then
			return self.lastSpeed * 0.621371 * 3600
		end
		
		return self.lastSpeed * 3600
	end
	
	-- Swap in our function
	if self.spec_dashboard ~= nil and self.spec_dashboard.dashboards ~= nil then
			for index, entry in pairs(self.spec_dashboard.dashboards) do
				if entry.valueFunc ~= nil and entry.valueFunc == "getLastSpeed" and (entry.displayTypeIndex == Dashboard.TYPES.TEXT or entry.displayTypeIndex == Dashboard.TYPES.NUMBER) then
					entry.valueFunc = "getLastSpeedRD"
				end
			end
	end
	
	-- End Real Dashboard Speed


	if self.xmlFile:hasProperty(baseKey) then
        isActive = true
		
		local realDashboardPath = RealDashboard.REALDASHBOARD_CONFIG_XML_KEY

        local fillTypeCategories = xmlFile:getValue(realDashboardPath .. "#fillTypeCategories")
        local fillTypeNames = xmlFile:getValue(realDashboardPath .. "#fillTypes")
        local allowedFillTypes = {}
        local useDefaultCategory = true

        if fillTypeCategories ~= nil then
            local fillTypeList = g_fillTypeManager:getFillTypesByCategoryNames(fillTypeCategories)
            if fillTypeList ~= nil then
                for _, fillTypeIndex in pairs(fillTypeList) do
                    allowedFillTypes[fillTypeIndex] = true
                    useDefaultCategory = false
                end
            end
        end

        if fillTypeNames ~= nil then
            local fillTypeList = g_fillTypeManager:getFillTypesByNames(fillTypeNames)
            if fillTypeList ~= nil then
                for _, fillTypeIndex in pairs(fillTypeList) do
                    allowedFillTypes[fillTypeIndex] = true
                    useDefaultCategory = false
                end
            end
        end

        if useDefaultCategory then -- nothing was specified
            local fillTypeList = g_fillTypeManager:getFillTypesByCategoryNames("bulk")
            if fillTypeList ~= nil then
                for _, fillTypeIndex in pairs(fillTypeList) do
                    allowedFillTypes[fillTypeIndex] = true
                end
            end
        end

        spec.allowedFillTypes = allowedFillTypes

        local volumeUnits = {}
		
		table.insert(volumeUnits, {name="liters", factor=1})
		table.insert(volumeUnits, {name="CubicMeters", factor=0.001})
		table.insert(volumeUnits, {name="BushelUS", factor=0.028378})
		table.insert(volumeUnits, {name="BushelUK", factor=0.027496})
		table.insert(volumeUnits, {name="GallonUS", factor=0.264172})
		table.insert(volumeUnits, {name="GallonUK", factor=0.219969})
		
		
		for i, volumeUnitInfo in ipairs(volumeUnits) do
            volumeUnitInfo.index = i
            volumeUnitInfo.title = g_i18n:getText("rdb_unit_"..volumeUnitInfo.name)
        end
		
        local massUnits = {}
		
		table.insert(massUnits, {name="Kilogram", factor=1000})
		table.insert(massUnits, {name="Pound", factor=2204.622559})
		table.insert(massUnits, {name="TonShort", factor=1.102311})
		table.insert(massUnits, {name="TonLong", factor=0.984207})
		table.insert(massUnits, {name="Tonne", factor=1.000})
		
		for i, massUnitInfo in ipairs(massUnits) do
            massUnitInfo.index = i
            massUnitInfo.title = g_i18n:getText("rdb_unit_"..massUnitInfo.name)
        end

        local densityUnits = {}

        table.insert(densityUnits, {name="kgPerL",    factor=1000})
        table.insert(densityUnits, {name="kgPerM3",   factor=1000000})
        table.insert(densityUnits, {name="lbsPerBu",  factor=77688.851269})
        table.insert(densityUnits, {name="lbsPerFt3", factor=62427.960570})
        table.insert(densityUnits, {name="lbsPerGal", factor=8345.404452})

        for i, densityUnitInfo in ipairs(densityUnits) do
            densityUnitInfo.index = i
            densityUnitInfo.title = g_i18n:getText("rdb_unit_"..densityUnitInfo.name)
        end

        spec.volumeUnits = volumeUnits
        spec.volumeUnitIndex = 1

        spec.massUnits = massUnits
        spec.massUnitIndex = 1

        spec.densityUnits = densityUnits
        spec.densityUnitIndex = 1

        -- load dashboards
        if self.loadDashboardsFromXML ~= nil then
            self:loadDashboardsFromXML(xmlFile, dashboardKey,
                {
                    valueTypeToLoad = "fillLevel",
                    valueObject = self,
                    valueFunc = "rdbGetFillLevel",
                    minFunc = 0,
                    maxFunc = 999999
                }
            )
            self:loadDashboardsFromXML(xmlFile, dashboardKey,
                {
                    valueTypeToLoad = "fillMass",
                    valueObject = self,
                    valueFunc = "rdbGetFillMass",
                    minFunc = 0,
                    maxFunc = 999999,
                }
            )
            self:loadDashboardsFromXML(xmlFile, dashboardKey,
                {
                    valueTypeToLoad = "fillDensity",
                    valueObject = self,
                    valueFunc = "rdbGetFillDensity",
                    minFunc = 0,
                    maxFunc = 99999,
                }
            )
        end
    end

    spec.displayModeIndex = 1
    spec.displayModes = {"normal", "root", "total"}
    spec.isActive = isActive
end

function RealDashboard:onUpdate(dt, isActiveForInput, isActiveForInputIgnoreSelection, isSelected)
    local spec = self[g_specName]

    if self.isClient then
        if spec.isActive then
            if self:getIsEntered() and self:getIsActiveForInput(true, true) then -- allow AI
                local _, displayModeName = self:rdbGetDisplayMode()
                local displayModeText = g_i18n:getText("rdb_mode_"..displayModeName)

                g_currentMission:addExtraPrintText(displayModeText)

                local volumeUnitInfo = self:rdbGetVolumeUnit()
                if volumeUnitInfo ~= nil then
                    local unitName = volumeUnitInfo.title
                    g_currentMission:addExtraPrintText(g_i18n:getText("rdb_volume_unit")..unitName)
                end

                local massUnitInfo = self:rdbGetMassUnit()
                if massUnitInfo ~= nil then
                    local unitName = massUnitInfo.title
                    g_currentMission:addExtraPrintText(g_i18n:getText("rdb_mass_unit")..unitName)
                end

                local densityUnitInfo = self:rdbGetDensityUnit()
                if densityUnitInfo ~= nil then
                    local unitTitle = densityUnitInfo.title
                    g_currentMission:addExtraPrintText(g_i18n:getText("rdb_density_unit")..unitTitle)
                end

                self:raiseActive()
            end
        end
    end
end

function RealDashboard:onRegisterActionEvents(isActiveForInput, isActiveForInputIgnoreSelection)
    if self.isClient then
        local spec = self[g_specName]

        self:clearActionEventsTable(spec.actionEvents)

        if self:getIsActiveForInput(true, true) then -- ignore selection, allow ai
            if spec.isActive then
                local _, actionEventId01 = self:addActionEvent(spec.actionEvents, InputAction.RDB_TOGGLE_MODE, self, RealDashboard.actionToggleMode, false, true, false, true)
                g_inputBinding:setActionEventText(actionEventId01, g_i18n:getText("rdb_action_toggleMode"))
                g_inputBinding:setActionEventTextPriority(actionEventId01, GS_PRIO_LOW)
                spec.actionToggleModeId = actionEventId01

                local _, actionEventId02 = self:addActionEvent(spec.actionEvents, InputAction.RDB_TOGGLE_VOLUME_UNIT, self, RealDashboard.actionToggleVolumeUnit, false, true, false, true)
                g_inputBinding:setActionEventText(actionEventId02, g_i18n:getText("rdb_action_toggleVolumeUnit"))
                g_inputBinding:setActionEventTextPriority(actionEventId02, GS_PRIO_VERY_LOW)
                spec.actionToggleVolumeUnitId = actionEventId02

                local _, actionEventId03 = self:addActionEvent(spec.actionEvents, InputAction.RDB_TOGGLE_MASS_UNIT, self, RealDashboard.actionToggleMassUnit, false, true, false, true)
                g_inputBinding:setActionEventText(actionEventId03, g_i18n:getText("rdb_action_toggleMassUnit"))
                g_inputBinding:setActionEventTextPriority(actionEventId03, GS_PRIO_VERY_LOW)
                spec.actionToggleMassUnitId = actionEventId03

                local _, actionEventId04 = self:addActionEvent(spec.actionEvents, InputAction.RDB_TOGGLE_DENSITY_UNIT, self, RealDashboard.actionToggleDensityUnit, false, true, false, true)
                g_inputBinding:setActionEventText(actionEventId04, g_i18n:getText("rdb_action_toggleDensityUnit"))
                g_inputBinding:setActionEventTextPriority(actionEventId04, GS_PRIO_VERY_LOW)
                spec.actionToggleDensityUnitId = actionEventId04
            end
        end
    end
end

-- <<[Specialization Functions]>> -----------------------------------------------------------------

function RealDashboard:rdbGetFillLevelInfo()
    local selectedVehicle = Utils.getNoNil(self:getSelectedVehicle(), self)
    local rootVehicle = Utils.getNoNil(self:getRootVehicle(), self)

    local displayMode = self:rdbGetDisplayMode()
    local fillLevelInfo = {}
	
	function fillLevelInfo.addFillLevel(_, fillType, fillLevel, capacity, uiPrecision, maxReached)
		table.insert(self.fillLevels, {fillType=fillType, fillLevel=fillLevel, capacity=capacity})
	end

    if displayMode == RealDashboard.DISPLAY_MODE.TOTAL then
        self.fillLevels = {} -- Clear

        rootVehicle:getFillLevelInformation(fillLevelInfo)
		return self.fillLevels
    else
        local displayVehicle = selectedVehicle
        if displayMode == RealDashboard.DISPLAY_MODE.ROOT then
            displayVehicle = rootVehicle
        end

        local fillUnitSpec = displayVehicle.spec_fillUnit
        if fillUnitSpec ~= nil then
            for _, fillUnit in pairs(fillUnitSpec.fillUnits) do
                local capacity = Utils.getNoNil(fillUnit.capacity, 0)

                if capacity > 0 and capacity < math.huge and fillUnit.showOnHud then
                    local fillType  = fillUnit.fillType
                    local fillLevel = fillUnit.fillLevel
                    local added = false

                    for _, entry in ipairs(fillLevelInfo) do
                        if entry.fillType == fillType then
                            entry.fillLevel = entry.fillLevel + fillLevel
                            entry.capacity = entry.capacity + capacity
                            added = true
                            break
                        end
                    end

                    if not added then
                        table.insert(fillLevelInfo, {fillType=fillType, fillLevel=fillLevel, capacity=capacity})
                    end
                end
            end
        end
    end
    return fillLevelInfo
end

function RealDashboard:rdbGetDisplayMode()
    local spec = self[g_specName]
    local displayModeIndex = spec.displayModeIndex
    local displayModeName = spec.displayModes[displayModeIndex]

    return displayModeIndex, displayModeName
end

function RealDashboard:rdbGetVolumeUnit(unitIndex)
    local spec = self[g_specName]
    unitIndex = Utils.getNoNil(unitIndex, spec.volumeUnitIndex)

    local unitInfo = {
        name = "liter",
        title = g_i18n:getText("unit_liter"),
        titleShort = g_i18n:getText("unit_literShort")
    }
    local unitFactor = 1

    local volumeUnitInfo = spec.volumeUnits[unitIndex]
    if volumeUnitInfo ~= nil then
        unitInfo = volumeUnitInfo
        unitFactor = volumeUnitInfo.factor
    end

    return unitInfo, unitFactor
end

function RealDashboard:rdbGetMassUnit(fillTypeIndex, unitIndex)
    local spec = self[g_specName]
    unitIndex = Utils.getNoNil(unitIndex, spec.massUnitIndex)

    local unitInfo = {
        name = "kilogram",
        title = g_i18n:getText("unit_kg"), -- there is no vanilla long title for kilogram (or any mass unit)
        titleShort = g_i18n:getText("unit_kg")
    }

    local fillTypeInfo = g_fillTypeManager:getFillTypeByIndex(fillTypeIndex)
    local massPerLiter = 0
    local unitFactor = 1000 -- mt/l to kg/l

    if fillTypeInfo ~= nil then
        massPerLiter = Utils.getNoNil(fillTypeInfo.massPerLiter, massPerLiter)
    end

    local massUnitInfo = spec.massUnits[unitIndex]
    if massUnitInfo ~= nil then
        unitInfo = massUnitInfo
        unitFactor = massUnitInfo.factor
    end

    unitFactor = unitFactor * massPerLiter
    return unitInfo, unitFactor
end

function RealDashboard:rdbGetDensityUnit(unitIndex)
    local spec = self[g_specName]
    unitIndex = Utils.getNoNil(unitIndex, spec.densityUnitIndex)

    local densityUnitInfo = spec.densityUnits[unitIndex]
    if densityUnitInfo ~= nil then
        densityUnitInfo = spec.densityUnits[spec.densityUnitIndex]
    end

    return densityUnitInfo, densityUnitInfo.factor
end

-- <<[Dashboard Functions]>> ----------------------------------------------------------------------

function RealDashboard:rdbGetFillLevel()
    local spec = self[g_specName]
    local totalVolume = 0

    if self:getIsActive() then
        local fillLevelInfo = self:rdbGetFillLevelInfo()

        for _, entry in ipairs(fillLevelInfo) do
            local fillTypeInfo = g_fillTypeManager:getFillTypeByIndex(entry.fillType)
            if fillTypeInfo ~= nil and spec.allowedFillTypes[fillTypeInfo.index] then
                local fillLevel = Utils.getNoNil(entry.fillLevel, 0)
                local _, unitFactor = self:rdbGetVolumeUnit()

                if fillLevel > 0 and fillLevel < math.huge then
                    totalVolume = totalVolume + (fillLevel * unitFactor)
                end
            end
        end
    end

    return totalVolume
end

function RealDashboard:rdbGetFillMass()
    local spec = self[g_specName]
    local totalMass = 0

    if self:getIsActive() then
        local fillLevelInfo = self:rdbGetFillLevelInfo()

        for _, entry in ipairs(fillLevelInfo) do
            local fillTypeInfo = g_fillTypeManager:getFillTypeByIndex(entry.fillType)
            if fillTypeInfo ~= nil and spec.allowedFillTypes[fillTypeInfo.index] then
                local fillLevel = Utils.getNoNil(entry.fillLevel, 0)
                local _, unitFactor = self:rdbGetMassUnit(fillTypeInfo.index) -- fillType passed to get mass value

                if fillLevel > 0 and fillLevel < math.huge then
                    totalMass = totalMass + (fillLevel * unitFactor)
                end
            end
        end
    end

    return totalMass
end

function RealDashboard:rdbGetFillDensity()
    local spec = self[g_specName]
    local totalDensity = 0

    if self:getIsActive() then
        local fillLevelInfo = self:rdbGetFillLevelInfo()
        local numEntries = #fillLevelInfo

        for _, entry in ipairs(fillLevelInfo) do
            local fillTypeInfo = g_fillTypeManager:getFillTypeByIndex(entry.fillType)
            if fillTypeInfo ~= nil and spec.allowedFillTypes[fillTypeInfo.index] then
                local fillTypeIndex = fillTypeInfo.index
                local massPerLiter = fillTypeInfo.massPerLiter
                local _, densityUnitFactor = self:rdbGetDensityUnit()
                totalDensity = totalDensity + (massPerLiter * densityUnitFactor)
            end
        end

        if numEntries > 0 then
            totalDensity = totalDensity / numEntries -- get average value
        end
    end

    return totalDensity
end

-- <<[Action Events]]>> ---------------------------------------------------------------------------

function RealDashboard:actionToggleMode(actionName, inputValue, callbackState, isAnalog)
    local spec = self[g_specName]
    local displayModeIndex = spec.displayModeIndex
    local numDisplayModes = #spec.displayModes

    displayModeIndex = displayModeIndex + 1
    if displayModeIndex > numDisplayModes then
        displayModeIndex = 1
    end

    spec.displayModeIndex = displayModeIndex
    self:raiseActive()
end

function RealDashboard:actionToggleVolumeUnit(actionName, inputValue, callbackState, isAnalog)
    local spec = self[g_specName]
    local volumeUnitIndex = spec.volumeUnitIndex

    volumeUnitIndex = volumeUnitIndex + 1
    if volumeUnitIndex > #spec.volumeUnits then
        volumeUnitIndex = 1
    end

    spec.volumeUnitIndex = volumeUnitIndex
    self:raiseActive()
end

function RealDashboard:actionToggleMassUnit(actionName, inputValue, callbackState, isAnalog)
    local spec = self[g_specName]
    local massUnitIndex = spec.massUnitIndex

    massUnitIndex = massUnitIndex + 1
    if massUnitIndex > #spec.massUnits then
        massUnitIndex = 1
    end

    spec.massUnitIndex = massUnitIndex
    self:raiseActive()
end

function RealDashboard:actionToggleDensityUnit(actionName, inputValue, callbackState, isAnalog)
    local spec = self[g_specName]
    local densityUnitIndex = spec.densityUnitIndex

    densityUnitIndex = densityUnitIndex + 1
    if densityUnitIndex > #spec.densityUnits then
        densityUnitIndex = 1
    end

    spec.densityUnitIndex = densityUnitIndex
    self:raiseActive()
end